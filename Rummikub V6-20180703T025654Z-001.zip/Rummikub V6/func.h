#ifndef FUNC_H_INCLUDED
#define FUNC_H_INCLUDED
#define TAMANHO 106
#define LARGURA 22
#define ALTURA 10
typedef struct{
    char num;
    char cor;
    int estado;
}Carta;
void ler_arquivo(Carta *cartas); //OK
void embaralhar(Carta *cartas); // OK
void distribuir_cartas(Carta *cartas, int num_jogadores); //OK
void splash();
void menu();
void imprime_tabela(int **matriz, Carta *cartas);
void exibe_deck(Carta *cartas,int nJog);
void copiar_tabuleiro(int** tabuleiro1,int **tabuleiro2);
void copiar_baralho(Carta *cartas, Carta *copia);
void insere_carta(Carta *cartas, int **tabuleiro,int n_jogador);
void move_carta(int **tabuleiro);
void compra_carta(Carta *cartas,int n_jogador);
int verifica_jogada(int **tabuleiro, Carta *cartas, int rodada, Carta *carta_original, int n_jogadores);
int identifica_jogada(int **tabuleiro, int linha,int coluna, Carta *cartas);
int verifica_grupo(int **tabuleiro, int linha, int coluna, Carta *cartas);
int procura_coringa(int tamanho,int **tabuleiro, Carta *cartas,int linha,int coluna);
int verifica_lista(int **tabuleiro, int linha, int coluna, Carta *cartas);
int soma_cartas(int numJog, Carta *cartas);
int conta_cartas(int numJog, Carta *cartas);
int verifica_vitoria(int n_jogadores,int numJog,Carta *cartas);
#endif // FUNC_H_INCLUDED
