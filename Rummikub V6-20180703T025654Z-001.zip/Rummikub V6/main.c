#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <locale.h>
#include <time.h>
#include <locale.h>
#include <string.h>
#include "func.h"
int main()
{
    system("mode con:cols=110 lines=45");
    setlocale(LC_ALL, "Portuguese");
    splash();
    while(1){
    menu();
    system("cls");
    int rodada = 0;
    int fim_jogo = 1;
    int **tabuleiro = malloc(ALTURA*sizeof(int*));
    for(int x = 0;x<ALTURA;x++){
        tabuleiro[x] = malloc(LARGURA*sizeof(int));
        for(int y = 0;y<LARGURA;y++){
            tabuleiro[x][y] = -1;
        }
    }
    int **tabuleiro_prov = malloc(ALTURA*sizeof(int*));
    for(int x = 0;x<ALTURA;x++){
        tabuleiro_prov[x] = malloc(LARGURA*sizeof(int));
        for(int y = 0;y<LARGURA;y++){
            tabuleiro[x][y] = -1;
        }
    }
    int opcao =0;
    int num_jogadores=0;
    Carta *cartas = malloc(TAMANHO*sizeof(Carta));
    Carta *cartas_prov = malloc(TAMANHO*sizeof(Carta));
    ler_arquivo(cartas);
    setbuf(stdin,NULL);
    printf("Deseja emabaralhar as cartas? \n");
    printf("1 - SIM\n");
    printf("Qualquer digito - NAO\n");
    scanf("%d",&opcao);
    if(opcao == 1){
        embaralhar(cartas);
    }
    opcao = 0;
    do{
        system("cls");
        printf("Digite o n�mero de jogadores (1 a 5): \n");
        setbuf(stdin,NULL);
        scanf("%d", &opcao);
        if(opcao<1||opcao>5){
            printf("Escolha incorreta. Digite novamente. \n \n");
            system("pause");
        }else{
            num_jogadores = opcao;
        }
    }while(opcao<1||opcao>5);
    distribuir_cartas(cartas,num_jogadores);
    ////////////////////////////////////////////////////////////////////////////////////////////
    while(fim_jogo){
        int escolha;
        int opc=1;
        copiar_baralho(cartas,cartas_prov);
        copiar_tabuleiro(tabuleiro,tabuleiro_prov);
        system("cls");
        imprime_tabela(tabuleiro_prov,cartas);
        exibe_deck(cartas_prov,rodada%num_jogadores+1);
        printf("\n\n\n\t\t\t\tVez do jogador %d:", rodada%num_jogadores+1);
        printf("\n\n\n\n\n\n\t\t\t\t Deseja Comprar carta?\n");
        printf("\t\t\t\t SIM - 1\n");
        printf("\t\t\t\t NAO - Qualquer tecla\n");
        setbuf(stdin,NULL);
        printf("\t\t\t\t >> ");
        scanf("%d",&escolha);
        if(escolha ==1){
            compra_carta(cartas,rodada%num_jogadores+1);
            opc = 0;
        }else{
                while(opc){
                system("cls");
                imprime_tabela(tabuleiro_prov,cartas);
                exibe_deck(cartas_prov,rodada%num_jogadores+1);
                printf("\n\n\n\t\t\t\tVez do jogador %d: \n \n \n", rodada%num_jogadores+1);
                printf("\t\t\t\t OPCOES \n");
                printf("\t\t\t\t 1- Inserir carta no tabuleiro \n");
                printf("\t\t\t\t 2- Mover carta no tabuleiro \n");
                printf("\t\t\t\t 3- Verificar e confirmar jogada \n");
                printf("\t\t\t\t 4- Desfazer Jogada\n");
                setbuf(stdin, NULL);
                scanf("%d",&escolha);
                switch(escolha){
                    case 1:
                        insere_carta(cartas_prov,tabuleiro_prov,rodada%num_jogadores+1);
                    break;
                    case 2:
                        move_carta(tabuleiro_prov);
                    break;
                    case 3:
                        if(verifica_jogada(tabuleiro_prov,cartas_prov,rodada,cartas,num_jogadores)){
                            printf("Jogada realizada com sucesso!\n");
                            copiar_baralho(cartas_prov,cartas);
                            copiar_tabuleiro(tabuleiro_prov,tabuleiro);
                            system("pause");
                            opc = 0;
                        }else{
                            printf("Jogada inv�lida. \n");
                            rodada--;
                            opc = 0;
                            system("pause");
                        }

                        break;
                    case 4:
                        rodada--;
                        opc = 0;
                        break;
                    default:
                        printf("Escolha inv�lida. Digite novamente. \n \n");
                        system("pause");
                    break;
                }
            }
        }
        if(verifica_vitoria(num_jogadores,rodada%num_jogadores+1,cartas)){
                if(verifica_vitoria(num_jogadores,rodada%num_jogadores+1,cartas) != 10){
                    printf("O JOGADOR %d � O VENCEDOR\n\n", verifica_vitoria(num_jogadores,rodada%num_jogadores+1,cartas));
                    fim_jogo = 0;
                    system("pause");
                }else{
                    printf("EMPATE!!!\n");
                    fim_jogo = 0;
                    system("pause");
                }
        }
    rodada++;
    }
    }
    return 0;
}
