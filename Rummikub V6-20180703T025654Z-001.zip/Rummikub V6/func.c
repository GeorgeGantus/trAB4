#include "func.h"
#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
#include <string.h>
void menu(void){
    int opc = 0;
    while(1){
    system("cls");
    printf("\t\t\t\t\t\t Rummikub\n\n");
    printf("\t\t\t\t\t 1-Novo Jogo \n\n");
    printf("\t\t\t\t\t 2-Informa��es \n\n");
    printf("\t\t\t\t\t 3-Sair \n\n");
    printf("Digite a op��o desejada: ");
    setbuf(stdin,NULL);
    scanf("%d",&opc);
        switch(opc){
        case 1:
            return;
            break;
        case 2:
            printf("Para mais informacoes, acesse https://pt.wikipedia.org/wiki/Rummikub\n");
            system("pause");
            break;
        case 3:
            exit(0);
            break;
        default:
            printf("digito invalido tente novamente\n");
            system("pause");
        }
    }
}
void splash(void){
    printf("\n\n\n\n\n\n\n");
    printf("\t\t  ########  ##     ## ##     ## ##     ## #### ##    ## ##     ## ######## \n");
    printf("\t\t  ##     ## ##     ## ###   ### ###   ###  ##  ##   ##  ##     ## ##     ## \n");
    printf("\t\t  ##     ## ##     ## #### #### #### ####  ##  ##  ##   ##     ## ##     ## \n");
    printf("\t\t  ########  ##     ## ## ### ## ## ### ##  ##  #####    ##     ## ######## \n");
    printf("\t\t  ##   ##   ##     ## ##     ## ##     ##  ##  ##  ##   ##     ## ##     ## \n");
    printf("\t\t  ##    ##  ##     ## ##     ## ##     ##  ##  ##   ##  ##     ## ##     ## \n");
    printf("\t\t  ##     ##  #######  ##     ## ##     ## #### ##    ##  #######  ######## \n");
    printf("\n\n\n\n\n\n\n\n\n\n\n\n");
    system("pause");
}
void imprime_tabela(int **tabuleiro,Carta *cartas){
    printf("\t \t");
    for(int y = 0;y<LARGURA-2;y++){
            y>9?printf("%d  ",y):printf("%d   ",y);
        }
    for(int x = 0;x<ALTURA;x++){

        printf("\n \n \t %d\t",x);
        for(int y = 0;y<LARGURA-2;y++){
            char posicao[3] = ". ";
            if(tabuleiro[x][y] != -1){
                posicao[0] = cartas[tabuleiro[x][y]].num;
                posicao[1] = cartas[tabuleiro[x][y]].cor;
            }
            printf("%s",posicao);
            printf("  ");
        }

    }
}
void embaralhar(Carta *cartas){
    int count = 0;
    srand(time(NULL));
    while(count < TAMANHO){
        int posicao1 = rand()%105;
        int posicao2 = rand()%105;
        char temp;
        temp = cartas[posicao1].num;
        cartas[posicao1].num = cartas[posicao2].num;
        cartas[posicao2].num = temp;
        temp = cartas[posicao1].cor;
        cartas[posicao1].cor = cartas[posicao2].cor;
        cartas[posicao2].cor = temp;
        count++;
    }
}
void distribuir_cartas(Carta *cartas, int num_jogadores){
    int jogador = 0;
    for(int x = 0; x<14*num_jogadores;x++){
        cartas[x].estado = jogador%num_jogadores +1;
        jogador++;
    }
}
void ler_arquivo(Carta *cartas){
    FILE *arquivo = fopen("baralho.txt","a+");
    int count = 0;
    while(count <TAMANHO){
        cartas[count].num = fgetc(arquivo);
        cartas[count].cor = fgetc(arquivo);
        fgetc(arquivo);
        cartas[count].estado = -1;
        count++;
    }
    fclose(arquivo);
}
void exibe_deck(Carta *cartas,int nJog){
    int contador = 0;
    printf("\n \n\n");
    printf("   ID:   ");
    for(int i =0;i < TAMANHO;i++){
        if(cartas[i].estado == nJog){
            contador++;
            if(contador == 26){
                printf("\n");
            }
            i > 9?printf("%d  ",i):printf("%d   ",i);
        }
    }
    contador = 0;
    printf("\n");
    printf("Carta:   ");
    for(int i=0;i < TAMANHO;i++){
        if(cartas[i].estado == nJog){
            contador++;
            if(contador == 26){
                printf("\n");
            }
            printf("%c%c  ",cartas[i].num,cartas[i].cor);
        }
    }
    printf("\n");
    printf("\t\t\t\t\t\t\t\t\t\t CARTAS RESTANTES: %d",conta_cartas(-1,cartas));
}

void copiar_tabuleiro(int **tabuleiro1, int **tabuleiro2){
    for(int x = 0;x<ALTURA;x++){
        for(int y = 0;y<LARGURA;y++){
            tabuleiro2[x][y] = tabuleiro1[x][y];
        }
    }

}
void copiar_baralho(Carta *cartas, Carta *copia){
    for(int i = 0;i < TAMANHO;i++){
        copia[i] = cartas[i];
    }
}
void insere_carta(Carta *cartas, int **tabuleiro, int n_jogador){
    int id, linha, coluna;
    setbuf(stdin,NULL);
    printf("Digite o id da carta que deseja inserir: \n");
    scanf("%d", &id);
    if(id<0||id>TAMANHO){
        printf("Esta carta n�o est� em seu deck. \n");
        system("pause");
    }else{
    if(cartas[id].estado != n_jogador){
        printf("Esta carta n�o est� em seu deck. \n");
         system("pause");
    }else{
        setbuf(stdin,NULL);
        printf("Digite a linha do tabuleiro: \n");
        scanf("%d",&linha);
        if(linha>9||linha<0){
            printf("Esta linha n�o existe.\n");
            system("pause");
        }else{
        setbuf(stdin,NULL);
        printf("Digite a coluna do tabuleiro: \n");
        scanf("%d", &coluna);
        if(coluna>19||coluna<0){
            printf("Esta coluna n�o existe. \n");
             system("pause");
        }else{
            if(tabuleiro[linha][coluna]!=-1){
                printf("Posicao ocupada! \n");
                 system("pause");
            }else{
                cartas[id].estado = 0;
                tabuleiro[linha][coluna] = id;
            }
        }
    }
    }
    }
}
void move_carta(int **tabuleiro){
    int linha,coluna,linha2,coluna2;
    setbuf(stdin,NULL);
    printf("Digite a linha da carta: ");
    scanf("%d", &linha);
    if(linha<0||linha>9){
        printf("Linha inv�lida. \n");
        system("pause");
    }else{
        setbuf(stdin,NULL);
        printf("Digite a coluna da carta: ");
        scanf("%d", &coluna);
        if(coluna<0||coluna>19){
            printf("Coluna inv�lida! \n");
            system("pause");
        }else if(tabuleiro[linha][coluna]==-1){
            printf("Campo vazio!\n");
            system("pause");
        }else{
            setbuf(stdin, NULL);
            printf("Digite a nova linha: ");
            scanf("%d", &linha2);
            if(linha<0||linha>9){
                printf("Linha inv�lida");
            }else{
                setbuf(stdin,NULL);
                printf("Digite a nova coluna");
                scanf("%d", &coluna2);
                if(coluna<0||coluna>19){
                    printf("Coluna inv�lida.");
                }else if(tabuleiro[linha2][coluna2]!=-1){
                    printf("Campo ocupado");
                }else{
                    tabuleiro[linha2][coluna2] = tabuleiro[linha][coluna];
                    tabuleiro[linha][coluna] = -1;
                }
            }
        }
    }
}
void compra_carta(Carta *cartas, int n_jogador){
    for(int x =0;x<106;x++){
        if(cartas[x].estado == -1){
            cartas[x].estado = n_jogador;
            x = 106;
        }
    }
}
int verifica_jogada(int **tabuleiro, Carta *cartas,int rodada, Carta *cartas_original, int n_jogadores){
    static int soma_pad =0;
        if(conta_cartas(0,cartas)== conta_cartas(0,cartas_original))
            return 0;
    for(int linha = 0;linha<ALTURA;linha++){
            for(int coluna = 0;coluna<LARGURA;coluna++){
                    if(tabuleiro[linha][coluna]!=-1){
                        if(identifica_jogada(tabuleiro,linha,coluna,cartas) == 2){
                            if(!verifica_grupo(tabuleiro,linha,coluna,cartas)){
                                return 0;
                            }else{
                            coluna = verifica_grupo(tabuleiro,linha,coluna,cartas);
                            if(tabuleiro[linha][coluna+1]!=-1)
                                return 0;
                            }
                        }else if(identifica_jogada(tabuleiro,linha,coluna,cartas) == 1){
                            if(verifica_lista(tabuleiro,linha,coluna,cartas) ==0){
                                return 0;
                            }else{
                                coluna=verifica_lista(tabuleiro,linha,coluna,cartas);
                                printf("%d",coluna);

                            }
                        }else{
                            return 0;
                        }

                    }
            }
    }
    if(rodada < n_jogadores){
        int soma=0;
        for(int linha = 0;linha<ALTURA;linha++){
            for(int coluna = 0;coluna<LARGURA;coluna++){
                if(tabuleiro[linha][coluna] != -1){
                    if(cartas[tabuleiro[linha][coluna]].num == '*'){
                        soma+= 20;
                    }else{
                        soma+=cartas[tabuleiro[linha][coluna]].num >= 'A'?cartas[tabuleiro[linha][coluna]].num -'A'+10:cartas[tabuleiro[linha][coluna]].num - '0';
                    }
                }
            }
        }
        if(soma-soma_pad <30){
            soma_pad = soma;
            return 0;
        }
    }
   return 1;
}
/*A fun��o abaixo trata apenas de verifica��o superficial e trata alguns casos extremos
    casos extremos:
    jogada nao configura nem sequencia nem grupo dadas as numera��es das cartas
    OBS: a fun��o nao veriifica se a jogada esta certa apenas tenta identificar o que o jogador tentou fazer
*/
int identifica_jogada(int **tabuleiro, int linha, int coluna, Carta *cartas){
    int num1,num2,num3;
    char cor1,cor2,cor3;
    if(tabuleiro[linha][coluna+1] == -1 || tabuleiro[linha][coluna+2] == -1){
        return 0;
    }
    num1 = cartas[tabuleiro[linha][coluna]].num >= 'A'?cartas[tabuleiro[linha][coluna]].num -'A'+10:cartas[tabuleiro[linha][coluna]].num - '0';
    cor1 = cartas[tabuleiro[linha][coluna]].cor;
    num2 = cartas[tabuleiro[linha][coluna+1]].num >= 'A'?cartas[tabuleiro[linha][coluna+1]].num -'A'+10:cartas[tabuleiro[linha][coluna+1]].num - '0';
    cor2 = cartas[tabuleiro[linha][coluna+1]].cor;
    num3 = cartas[tabuleiro[linha][coluna+2]].num >= 'A'?cartas[tabuleiro[linha][coluna+2]].num -'A'+10:cartas[tabuleiro[linha][coluna+2]].num - '0';
    cor3 = cartas[tabuleiro[linha][coluna+2]].cor;
    if(cor1 == '*' || cor2 == '*' || cor3 == '*'){
        //ha pelo menos um coringa
        if(((cor1 == cor2 || cor1 == cor3) && cor1 =='*') || (cor2 == cor3 && cor2 == '*')){
            int num4;
            if(tabuleiro[linha][coluna+3] == -1){
                return 2;
            }
            num4 = cartas[tabuleiro[linha][coluna+3]].num >= 'A'?cartas[tabuleiro[linha][coluna+3]].num -'A'+10:cartas[tabuleiro[linha][coluna+3]].num - '0';
            if((num1 == num2&&cor1!= '*') || (num1 == num3&&cor1!= '*') || (num1 == num4&&cor1!= '*') || (num2 == num3&&cor2!= '*') || (num2 == num4&&cor2!= '*') || (num3 == num4&&cor3!= '*')){//suposto grupo
                return 2;
            }else{
                if(num1 == num2-1 || num1 == num3-2 || num1 == num4-3 || num2 == num3-1 || num2 == num4-2 || num3 == num4-1){//suposta sequencia
                    return 1;
                }else{//absurdo
                    return 0;
                }
            }
        }else{
            //apenas 1 coringa
            if(num1 == num2 || num1 == num3 || num2 == num3){
                return 2;
            }else{
                //ou � uma sequencia ou � um caso extremo
                if(num1 == num2-1 || num1 == num3-2 || num2 == num3-1){
                        //sequencia
                    return 1;
                }else{
                    return 0;
                }
            }
        }
    }else{//sem coringa
        if(num1 == num2){
            return 2;
        }else{
            if(num1 == num2-1){
                return 1;
            }else{
                return 0;
            }
        }
    }
}
int procura_coringa(int tamanho,int **tabuleiro, Carta *cartas,int linha,int coluna){
    int contador = 0;
    for(int i = 0;i < tamanho;i++){
        if(cartas[tabuleiro[linha][coluna+i]].cor == '*'){
            contador ++;
        }
    }
    return contador;
}
int verifica_grupo(int **tabuleiro, int linha, int coluna, Carta *cartas){
    int num1,num2,num3;
    char cor1,cor2,cor3;
    num1 = cartas[tabuleiro[linha][coluna]].num >= 'A'?cartas[tabuleiro[linha][coluna]].num -'A'+10:cartas[tabuleiro[linha][coluna]].num - '0';
    cor1 = cartas[tabuleiro[linha][coluna]].cor;
    num2 = cartas[tabuleiro[linha][coluna+1]].num >= 'A'?cartas[tabuleiro[linha][coluna+1]].num -'A'+10:cartas[tabuleiro[linha][coluna+1]].num - '0';
    cor2 = cartas[tabuleiro[linha][coluna+1]].cor;
    num3 = cartas[tabuleiro[linha][coluna+2]].num >= 'A'?cartas[tabuleiro[linha][coluna+2]].num -'A'+10:cartas[tabuleiro[linha][coluna+2]].num - '0';
    cor3 = cartas[tabuleiro[linha][coluna+2]].cor;
    int coringas;
    //verificar se � de 4 ou 3 cartas
    if(tabuleiro[linha][coluna+3] == -1){
        coringas = procura_coringa(3,tabuleiro,cartas,linha,coluna);
        //3 cartas
        if(coringas == 0){
            if(num1 == num2 && num1 == num3 && cor1 != cor2 && cor1 != cor3 && cor2 != cor3){
                return coluna+2;
            }else{
                return 0;
            }
        }else{
            if(coringas == 1){
                if((num1 == num2 || num1 == num3 || num2 == num3) && (cor1 != cor2 && cor1 != cor3 && cor2 != cor3)){
                    return coluna+2;
                }else{
                    return 0;
                }
            }else{
                return coluna+2;
            }
        }
    }else{
        coringas = procura_coringa(4,tabuleiro,cartas,linha,coluna);
        //4cartas
        int num4 = cartas[tabuleiro[linha][coluna+3]].num >= 'A'?cartas[tabuleiro[linha][coluna+3]].num -'A'+10:cartas[tabuleiro[linha][coluna+3]].num - '0';
        char cor4 = cartas[tabuleiro[linha][coluna+3]].cor;
        if(coringas == 0){
            if(num1 == num2 && num1 == num3 && num1 == num4 && cor1 != cor2 && cor1 != cor3 && cor1 != cor4 && cor2 != cor3 && cor2 != cor4 && cor3 != cor4){
                return coluna+3;
            }else{
            return 0;
            }
        }else{
            if(coringas == 1){
                if(cor1 != cor2 && cor1 != cor3 && cor1 != cor4 && cor2 != cor3 && cor2 != cor4 && cor3 != cor4){
                    //todas as cores sao diferentes basta conferir os numeros
                    if((num1 == num2 && num1 == num3)||(num2 == num3 && num3 == num4)||(num3 == num4 && num3 == num1)||(num1 == num2 && num1 == num4)){
                            return coluna+3;
                    }else{
                        return 0;
                    }
                }else{
                    return 0;
                }
            }else{
            //2coringas 4 cartas
            //express�o buagada (num1 == num2 && cor1 != cor2 && cor1 != '*')||(num1 == num3 && cor1 != cor3 && cor1 != '*')||(num1 == num4 && cor1 != cor4 && cor1 != *)||(num2 == num3 && cor2 != cor3 && cor2 != '*') || (num2 == num4 && cor2 != cor4 && cor2 != '*') || (num3 == num4 && cor3 != cor4 && cor3 != '*')
                if((num1 == num2 && cor1 != cor2 && cor1 != '*')||(num1 == num3 && cor1 != cor3 && cor1 != '*')||(num1 == num4 && cor1 != cor4 && cor1 != '*')||(num2 == num3 && cor2 != cor3 && cor2 != '*') || (num2 == num4 && cor2 != cor4 && cor2 != '*') || (num3 == num4 && cor3 != cor4 && cor3 != '*')){
                    return coluna+3;
                }else{
                    return 0;
                }
            }
        }
    }
}
int verifica_lista(int **tabuleiro, int linha, int coluna, Carta *cartas){
    int count = 1;
    char cor1 = cartas[tabuleiro[linha][coluna]].cor;
    char cor2 = cartas[tabuleiro[linha][coluna+1]].cor;
    if(cor1=='*'){
        coluna++;
        count++;
        if(cor2=='*')
        {
            coluna++;
            count++;
        }
    }
    if(cor1!='*'&&cor2=='*'){
        coluna+=2;
        count+=2;
    }
    int num1 = cartas[tabuleiro[linha][coluna]].num >= 'A'?cartas[tabuleiro[linha][coluna]].num -'A'+10:cartas[tabuleiro[linha][coluna]].num - '0';
    int num2 = cartas[tabuleiro[linha][coluna+1]].num >= 'A'?cartas[tabuleiro[linha][coluna+1]].num -'A'+10:cartas[tabuleiro[linha][coluna+1]].num - '0';
    cor1 = cartas[tabuleiro[linha][coluna]].cor;
    cor2 = cartas[tabuleiro[linha][coluna+1]].cor;
    while(tabuleiro[linha][coluna]!=-1){
        printf("%d ",count);
        if(cor1=='*'){
            count++;
            num1++;
            if(cor2=='*'){
                count++;
                num1++;
            }
        }else if(num1==num2-1&&cor1==cor2){
            count++;
            num1++;
        }
        coluna++;
        num2 = cartas[tabuleiro[linha][coluna+1]].num >= 'A'?cartas[tabuleiro[linha][coluna+1]].num -'A'+10:cartas[tabuleiro[linha][coluna+1]].num - '0';
    }
    if(count>=3){
        return coluna;
    }
    return 0;
}
int soma_cartas(int numJog, Carta *cartas){
    int soma = 0;
    for(int i = 0;i < TAMANHO;i++){
        if(cartas[i].estado == numJog){
            if(cartas[i].cor != '*'){
                soma += cartas[i].num >= 'A'?cartas[i].num -'A'+10:cartas[i].num - '0';
            }else{
                soma += 30;
            }
        }
    }
    return soma;
}
int conta_cartas(int numJog, Carta *cartas){
    int contagem = 0;
    for(int i = 0;i < TAMANHO;i++){
        if(cartas[i].estado == numJog){
            contagem++;
        }
    }
    return contagem;
}
int verifica_vitoria(int n_jogadores,int numJog,Carta *cartas){
    if(conta_cartas(numJog,cartas) == 0){
        return numJog;
    }else{
        if(conta_cartas(-1,cartas) == 0){
            int menor = 1;
            int sum = 0;
            int soma[n_jogadores];
            for(int i = 0;i < n_jogadores;i++){//preenche vetor
                soma[i] = soma_cartas(i+1,cartas);
            }
            for(int j = 0;j < n_jogadores-1;j++){
                if(soma[j] > soma[j+1]){
                    menor = j+2;
                }
            }
            sum = soma[menor-1];
            soma[menor-1] = 0;
            for(int k = 0;k < n_jogadores;k++){
                if(soma[k] == sum){
                    return 10;
                }
            }
            return menor;
        }else{
            return 0;
        }
    }
}
